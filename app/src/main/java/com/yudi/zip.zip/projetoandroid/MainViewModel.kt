package com.yudi.projetoandroid

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    // Instanciando o banco de dados (ajuste conforme necessário)
    private lateinit var bd: MeuBancoDeDados

    // LiveData para gerenciar o tema (claro/escuro)
    private val _isDark = MutableLiveData(false)
    val isDark: LiveData<Boolean> get() = _isDark

    // LiveData para resultado do login
    private val _loginResult = MutableLiveData<LoginResult>()
    val loginResult: LiveData<LoginResult> get() = _loginResult

    // LiveData para estado de carregamento (exibir ProgressBar)
    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> get() = _loading

    // Alterna o tema (claro/escuro)
    fun toggleTheme() {
        _isDark.value = _isDark.value?.not()
    }

    // Função de login
    fun onLoginClick(username: String, password: String) {
        // Ativando o carregamento
        _loading.value = true

        // Simulando a verificação de login (ajuste para uso real de banco de dados)
        if (bd.verificarLogin(username, password)) {
            _loginResult.value = LoginResult(success = true)
        } else {
            _loginResult.value = LoginResult(success = false, error = "Login ou senha incorretos")
        }

        // Desativando o carregamento após o processo
        _loading.value = false
    }
}

// Classe para encapsular o resultado do login
data class LoginResult(
    val success: Boolean,
    val error: String? = null
)
