package com.yudi.projetoandroid

data class Usuario(
    val idUser: Int,
    val nome: String,
    val email: String,
    val senha: String,
    val cpf: String,
    val telefone: String
)
