package com.yudi.projetoandroid

data class Jogo(

    val idJogo: Int,
    val nome: String,
    val tipo: String
)
