package com.yudi.projetoandroid

data class JogoSection(
    val tipo: String,
    val jogos: List<Jogo>
)
